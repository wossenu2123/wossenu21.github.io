// Functions to load items from Local Storage and display them
function loadInventory() {
    document.getElementById("Date").innerHTML = "Date :" + Date();
    const inventoryList = document.getElementById('inventory-list');
    inventoryList.innerHTML = '';

    // Retrieve inventory and sort alphabetically by item name
    const inventory = JSON.parse(localStorage.getItem('inventory')) || [];

    inventory.sort((a, b) => a.name.localeCompare(b.name));
    // Sort alphabetically by item name
    inventory.forEach((item, index) => {
        const isLowStock = item.quantity < 10;
        
        const li = document.createElement('li');
        li.className = isLowStock ? 'low-stock' : '';
        li.innerHTML = `${index +1}. ${item.name} - Quantity: ${item.quantity} ${item.unit}
        <button onclick="removeItem('${item.id}')">Remove</button>
        <button onclick="editItem('${item.id}')">Edit</button>`;

        inventoryList.appendChild(li);
    });
    calculateTotalInventory(); // Update the inventory count whenever the inventory is loaded
}

function madeBy() {
    let id = null;
    const elem = document.getElementById("wos");
    let pos = 0;
    clearInterval(id);
    id = setInterval(www, 5);
function www() {
    if (pos === 550) {
        clearInterval(id);
    } else {
        pos++;
        elem.style.top = pos + "0";
        elem.style.left = pos + "px";
    }
}
}

function calculateTotalInventory() {
    const inventory = JSON.parse(localStorage.getItem('inventory')) || [];
    const total = inventory.length;

    document.getElementById('total-inventory').textContent = total;
}

function searchItem() {
    const searchInput = document.getElementById('search-bar').value.toLowerCase();
    const inventoryList = document.getElementById('inventory-list');
    inventoryList.innerHTML = ''; // Clear the list before loading

    const inventory = JSON.parse(localStorage.getItem('inventory')) || [];

    const filteredItems = inventory.filter(item => 

        item.name.toLowerCase().includes(searchInput)
            );
            filteredItems.forEach((item, index) => {
                const li = document.createElement('li');
                li.innerHTML = `${index +1}. ${item.name} - Quantity: ${item.quantity} ${item.unit}
        <button onclick="removeItem('${item.id}')">Remove</button>
        <button onclick="editItem('${item.id}')">Edit</button>`;

        inventoryList.appendChild(li);
            });
}
// Function to add a new item to inventory
function addItem() {
    const itemName = document.getElementById('item-name').value;
    const itemQuantity = document.getElementById('item-quantity').value;
    const itemUnit = document.getElementById('item-unit').value;

    if (!itemName || !itemQuantity || !itemUnit) {
        alert('Please enter all the requirements.');
        return;
    }

    const inventory = JSON.parse(localStorage.getItem('inventory')) || [];
    const newItem = {
        id: Date.now().toString(), // use timeStamp as a unique ID
        name: itemName,
        quantity: parseInt(itemQuantity),
        unit: itemUnit
    };
    inventory.push(newItem);

    localStorage.setItem('inventory', JSON.stringify(inventory));

    // Clear input fields

    document.getElementById('item-name').value = '';

    document.getElementById('item-quantity').value = '';
     
    document.getElementById('item-unit').value = '';
    loadInventory();

}

// Function to remove an item from inventory
function removeItem(id) {
    let inventory = JSON.parse(localStorage.getItem('inventory')) || [];
    inventory = inventory.filter(item => item.id !== id); // Remove item by ID

localStorage.setItem('inventory', JSON.stringify(inventory));
   loadInventory();

}

function editItem(id) {
    const newQuantity = prompt('Enter the newquantity:');
    if (newQuantity === null || newQuantity === '') return; // Cancel or empty input

    const inventory = JSON.parse(localStorage.getItem('inventory')) || [];
    const item = inventory.find(item => item.id === id); // Find item by ID
    if(item) {
        item.quantity = parseInt(newQuantity); // Update the quantity

localStorage.setItem('inventory', JSON.stringify(inventory));
   loadInventory();
    } else {
        alert("Item not found.");
    }
}

// Load inventory on page load
window.onload = loadInventory;